# DVF dataset:

Real estate dataset recording transaction of year 2021 for residential assets (houses/flats). Columns are named in French, though fairly easy to understand. 

- code departement: string encoding the departement (e.g. '77' for Seine-et-Marne).
- surface bati: surface of the house/flat, in m².
- nombre pieces principales: number of main rooms (bedroom, living room, etc.). 
- surface terrain: surface of the garden, if any. `NaN` if no garden. 
- longitude, latitude: GNSS coordinates of the house/flat. 

- **target** valeur fonciere: the price at which the real estate asset was sold/bought, in euro.
